
import asyncio
import json
import sys
from playwright.async_api import async_playwright


async def check_console(url: str, timeout_ms: int = 5000):
    """Capture console errors/warnings from URL using Playwright."""
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()

            # Collect structured console data
            console_errors = []
            console_warnings = []
            page_errors = []

            # Capture console errors and warnings with structured data
            async def handle_console(msg):
                # Only capture errors and warnings (skip log, info, debug)
                if msg.type not in ["error", "warning"]:
                    return

                # Extract location info
                location_data = None
                if msg.location:
                    location_data = {
                        "url": msg.location.get("url", "unknown"),
                        "line": msg.location.get("lineNumber", 0),
                        "column": msg.location.get("columnNumber", 0)
                    }

                # Try to capture console arguments as JSON-serializable values
                args = []
                try:
                    for arg in msg.args:
                        try:
                            # Attempt to serialize argument value
                            arg_value = await arg.json_value()
                            args.append(arg_value)
                        except Exception:
                            # If serialization fails, just skip this argument
                            pass
                except Exception:
                    # If args extraction fails entirely, leave empty
                    pass

                # Build structured message data
                message_data = {
                    "type": msg.type,
                    "text": msg.text,
                    "location": location_data,
                    "args": args if args else None
                }

                # Categorize by type
                if msg.type == "error":
                    console_errors.append(message_data)
                elif msg.type == "warning":
                    console_warnings.append(message_data)

            # Capture page errors (uncaught exceptions) with stack trace
            def handle_page_error(error):
                error_data = {
                    "text": str(error),
                    "stack": getattr(error, "stack", None)
                }
                page_errors.append(error_data)

            page.on("console", handle_console)
            page.on("pageerror", handle_page_error)

            # Load page and wait for errors
            await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
            await page.wait_for_timeout(1500)  # Wait 1.5s for errors to appear (most surface within 500ms)

            # Check if Vite error overlay is present and extract structured data
            vite_overlay_data = None
            try:
                error_overlay = await page.query_selector("vite-error-overlay")
                if error_overlay:
                    # Extract structured error data from Vite overlay
                    overlay_info = await page.evaluate("""
                        () => {
                            const overlay = document.querySelector('vite-error-overlay');
                            if (overlay && overlay.shadowRoot) {
                                const message = overlay.shadowRoot.querySelector('.message');
                                const file = overlay.shadowRoot.querySelector('.file');
                                const frame = overlay.shadowRoot.querySelector('.frame');
                                return {
                                    message: message?.textContent || '',
                                    file: file?.textContent || '',
                                    frame: frame?.textContent || ''
                                };
                            }
                            return null;
                        }
                    """)
                    if overlay_info and overlay_info.get("message"):
                        vite_overlay_data = overlay_info
            except Exception:
                pass

            # Measure visible rendered text so the LLM can see what the page ACTUALLY
            # looks like post-hydration, not just the pre-JS HTML shell (that shell is
            # all `content_snippet` in validate_preview_url can show -- it's the raw
            # HTTP response body, captured before React/Vue/etc. ever runs). A page
            # can be HTTP 200 with 0 console errors/warnings and still be missing most
            # of its intended content (e.g. chrome renders, routed page content does
            # not) -- this gives the agent a real post-hydration snippet to sanity
            # check against, and a coarse "possibly blank" advisory signal.
            #
            # rendered_text_snippet/main_text_* are informational only -- never used to
            # fail the build (image-only/canvas-only pages are a known false-positive
            # source for a plain text-length check). structurally_empty_render is a
            # much narrower, low-false-positive signal (see below) that DOES surface as
            # a hard failure.
            rendered_text_length = 0
            rendered_text_snippet = ""
            main_text_length = 0
            main_text_snippet = ""
            structurally_empty_render = False
            try:
                render_probe = await page.evaluate(
                    """
                    () => {
                        const bodyText = ((document.body && document.body.innerText) || '').trim();
                        const mainEl = document.querySelector('main');
                        const mainText = mainEl ? (mainEl.innerText || '').trim() : '';
                        const mountEl = document.getElementById('root') || document.getElementById('app');
                        const mountText = mountEl ? (mountEl.innerText || '').trim() : '';
                        // A React/Vue mount point that hydrated but produced zero text,
                        // zero visual elements WITHIN THE MOUNT SUBTREE (a static logo/sprite
                        // elsewhere in the document, e.g. in a server-rendered shell outside
                        // the app root, must not mask a blank app render), an all-but-empty
                        // DOM subtree (at most one trivial wrapper -- catches a nested empty
                        // <div> even though it's not a *direct* child of mountEl), and no
                        // visible CSS box styling (background-image/color, borders) anywhere
                        // in that subtree is a strong, low-false-positive signal of a
                        // genuinely blank render (e.g. a component returning null/undefined
                        // for the whole tree) -- distinct from "chrome rendered but a section
                        // is thin" (stays advisory-only via rendered_text_length below, which
                        // IS whole-document) AND distinct from a CSS-only visible render
                        // (background-image hero, bordered blocks with no text/img/svg/canvas/
                        // video), which must NOT hard-fail. All of these are scoped to the
                        // mount subtree, not the whole document.
                        const mountDescendants = mountEl ? Array.from(mountEl.querySelectorAll('*')) : [];
                        const mountVisualCount = mountEl
                            ? mountEl.querySelectorAll('img, svg, canvas, video').length
                            : 0;
                        const hasVisibleBox = (el) => {
                            const cs = window.getComputedStyle(el);
                            if (cs.backgroundImage && cs.backgroundImage !== 'none') return true;
                            if (cs.backgroundColor && cs.backgroundColor !== 'rgba(0, 0, 0, 0)'
                                && cs.backgroundColor !== 'transparent') return true;
                            return ['borderTopWidth', 'borderBottomWidth', 'borderLeftWidth', 'borderRightWidth']
                                .some((prop) => parseFloat(cs[prop]) > 0);
                        };
                        const mountHasVisibleStyling = mountEl
                            && ([mountEl, ...mountDescendants]).some(hasVisibleBox);
                        const mountEmpty = !!mountEl && mountText.length === 0 && mountVisualCount === 0
                            && mountDescendants.length <= 1 && !mountHasVisibleStyling;
                        return {
                            bodyText: bodyText.slice(0, 500),
                            bodyTextLength: bodyText.length,
                            mainText: mainText.slice(0, 500),
                            mainTextLength: mainText.length,
                            mountEmpty: mountEmpty,
                        };
                    }
                    """
                )
                rendered_text_length = render_probe.get("bodyTextLength", 0)
                rendered_text_snippet = render_probe.get("bodyText", "")
                main_text_length = render_probe.get("mainTextLength", 0)
                main_text_snippet = render_probe.get("mainText", "")
                structurally_empty_render = bool(render_probe.get("mountEmpty", False))
            except Exception:
                pass

            await browser.close()

            # Build structured return data
            total_errors = len(console_errors) + len(page_errors)
            total_warnings = len(console_warnings)
            possibly_blank_render = rendered_text_length < 25

            # Always return the post-hydration render summary (not just on
            # errors/warnings/blank) so validate_preview_url can always show the agent
            # what actually rendered, instead of only the pre-hydration HTML shell.
            return {
                "errors": console_errors,
                "warnings": console_warnings,
                "page_errors": page_errors,
                "vite_overlay": vite_overlay_data,
                "total_errors": total_errors,
                "total_warnings": total_warnings,
                "rendered_text_length": rendered_text_length,
                "rendered_text_snippet": rendered_text_snippet,
                "main_text_length": main_text_length,
                "main_text_snippet": main_text_snippet,
                "possibly_blank_render": possibly_blank_render,
                "structurally_empty_render": structurally_empty_render,
            }

    except Exception as e:
        # Browser check failed - return error info
        return {"error": str(e)}


def _emit(result):
    """Print `result` as JSON that the caller can always parse.

    Console args captured via arg.json_value() can contain values the default
    JSON encoder cannot handle (e.g. bigint-like numbers, non-str dict keys,
    nested proxies). Without a fallback, a single bad arg makes json.dumps
    raise, the whole check exits non-zero, and the caller silently drops the
    browser-console result while still reporting VALIDATION: PASSED. default=str
    stringifies the unserializable leaf; the try/except guarantees we always
    emit parseable JSON on stdout.
    """
    try:
        print(json.dumps(result, default=str))
    except (TypeError, ValueError) as exc:
        print(json.dumps({"error": "result serialization failed: " + str(exc)}))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "URL argument required"}))
        sys.exit(1)

    url = sys.argv[1]
    timeout_ms = int(sys.argv[2]) if len(sys.argv) > 2 else 5000

    _emit(asyncio.run(check_console(url, timeout_ms)))
