
import asyncio
import base64
import ipaddress
import json
import socket
import sys
from urllib.parse import urljoin, urlparse

from playwright.async_api import async_playwright

_MAX_REDIRECT_HOPS = 10
_dns_verdicts = {}


def _resolves_private(host):
    """True if `host` resolves to a private/loopback/link-local/reserved IP."""
    if not host:
        return True
    try:
        infos = socket.getaddrinfo(host, None)
    except Exception:
        return True  # unresolvable -> refuse
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            return True
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_reserved
            or ip.is_multicast
            or ip.is_unspecified
        ):
            return True
    return False


def _is_private_host(host):
    """Memoized `_resolves_private`. getaddrinfo BLOCKS the event loop, and the
    guard now runs on EVERY request (a page pulls dozens from a handful of
    hosts), so resolve each host at most once per run."""
    if host not in _dns_verdicts:
        _dns_verdicts[host] = _resolves_private(host)
    return _dns_verdicts[host]


async def _install_redirect_guard(context, blocked):
    """Gate EVERY request against private addresses, following redirects MANUALLY.

    WHY NOT the naive `route.abort()` on each navigation: Chromium follows a 302
    INTERNALLY and does NOT fire a second route event for the destination.
    Verified against playwright 1.61 with a local 302 repro: route saw only the
    initial URL, and the private target WAS reached. Gating navigation events
    alone is therefore useless against redirects.

    What works (verified with the same repro — target blocked, never reached):
    fetch WITHOUT auto-following (`route.fetch(max_redirects=0)`), validate each
    Location hop ourselves, and only fulfill once we land on a public address.
    This is the in-browser analogue of `safe_get`'s manual redirect follow
    (url_safety.py:266-270), which we cannot use here because it is httpx-only.

    NAVIGATIONS ARE NOT SPECIAL — there is deliberately ONE code path here.
    A page that is itself public can reach a private address two other ways:
    directly, via <img>/fetch/script/CSS (never fires a navigation request), or
    through a PUBLIC subresource that 302s somewhere private (Chromium follows
    that internally too). Both are driven by untrusted page content, so a
    host-check-then-continue_() shortcut for subresources is not enough: every
    request walks its own redirect chain. This costs a proxied round trip per
    subresource, which is affordable because the guard is installed ONLY for
    external targets — own-preview calls (the hot path) skip routing entirely.

    Bound at CONTEXT scope, not page scope: `window.open` creates a new Page,
    and a page-scoped route would not cover it.

    SCHEMES: playwright does NOT route data:/blob: URLs (measured against 1.61 —
    a data: image still rendered and a blob: fetch resolved with zero route
    events), so `_is_private_host("")` failing closed on hostless URLs never
    strands inline images or fonts.

    KNOWN RESIDUAL — DNS rebinding. `_resolves_private` vets one answer and
    `route.fetch` then resolves again on its own connection. Closing it needs a
    pinned egress proxy; url_safety's IP pinning is httpx-only and cannot bind
    the socket playwright opens. Treat this gate as POLICY, NOT A SECURITY
    BOUNDARY: the sandbox has open egress (NOR-562) and the agent holds
    run_shell_command, so a determined AGENT reaches these addresses with one
    curl regardless. What the gate does buy is protection against a HOSTILE PAGE
    the agent was pointed at, which has no shell — hence gating page-driven
    requests is still worth doing properly.
    """

    async def _guard(route, request):
        url = request.url
        method = request.method
        body = request.post_data_buffer
        headers = dict(request.headers)
        for _ in range(_MAX_REDIRECT_HOPS):
            if _is_private_host(urlparse(url).hostname or ""):
                blocked.append(url)
                await route.abort()
                return
            try:
                # post_data MUST be passed explicitly on every hop. Omitting it
                # (or passing None) makes playwright refill the body from the
                # ORIGINAL request -- `post_data_buffer = request.post_data_buffer`
                # in _fetch.py -- which would resurrect a body we just dropped.
                # b"" takes the bytes branch, skips that fallback, and is falsy,
                # so no body goes out.
                resp = await route.fetch(
                    url=url,
                    method=method,
                    headers=headers,
                    post_data=body or b"",
                    max_redirects=0,
                )
            except Exception:
                await route.abort()
                return
            if 300 <= resp.status < 400:
                loc = resp.headers.get("location")
                if not loc:
                    break
                url = urljoin(url, loc)  # resolves relative Location headers
                # Follow BROWSER redirect semantics, not a blind replay: 301/302/
                # 303 downgrade to GET and drop the body, 307/308 preserve both.
                # Replaying a POST body to the redirect target is both wrong (the
                # page renders differently than in a real browser, so the
                # screenshot lies) and a resend of data the origin did not ask for.
                if resp.status in (301, 302, 303) and method not in ("GET", "HEAD"):
                    method = "GET"
                    body = b""
                    headers = {
                        k: v
                        for k, v in headers.items()
                        if k.lower() not in ("content-type", "content-length")
                    }
                continue
            await route.fulfill(response=resp)
            return
        blocked.append(url)
        await route.abort()

    await context.route("**/*", _guard)


async def inspect(url, actions, want_screenshot, guard_external):
    out = {
        "title": "",
        "url": url,
        "aria": "",
        "console_errors": [],
        "network_failures": [],
        "possibly_blank": False,
        "screenshot_b64": None,
        "steps": [],
        "blocked_requests": [],
        "navigation_error": None,
    }
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        try:
            # Explicit context so service workers can be blocked while guarding.
            # context.route does NOT intercept requests a service worker handles
            # (playwright's own docs say so), so a hostile page could register one
            # and route around the guard entirely. Only block while guarding: a
            # real preview may legitimately register a service worker (PWA), and
            # blocking it on the hot path would misrepresent the app being built.
            context = await browser.new_context(
                viewport={"width": 1280, "height": 720},
                service_workers="block" if guard_external else "allow",
            )
            page = await context.new_page()

            if guard_external:
                # Context scope, not page scope: covers popups from window.open.
                await _install_redirect_guard(context, out["blocked_requests"])

            page.on("console", lambda m: (
                out["console_errors"].append({"text": m.text})
                if m.type == "error" else None
            ))
            page.on("pageerror", lambda e: out["console_errors"].append({"text": str(e)}))
            page.on("requestfailed", lambda r: out["network_failures"].append(
                {"url": r.url, "failure": (r.failure or {}).get("errorText", "")
                 if isinstance(r.failure, dict) else str(r.failure)}
            ))

            # domcontentloaded + fixed settle. NEVER networkidle: it is the
            # dominant cost and a Vite HMR socket keeps the page from idling.
            #
            # MUST be caught: a guard abort makes goto RAISE (verified). Letting
            # it propagate would collapse the whole result into {"error": ...} in
            # main() and DROP blocked_requests — the tool would report a vague
            # failure instead of "we refused to navigate to a private address".
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=15000)
                await page.wait_for_timeout(1500)
            except Exception as exc:
                out["navigation_error"] = str(exc)

            for act in actions:
                step = {"action": json.dumps(act), "ok": True, "error": None}
                try:
                    kind = act.get("kind")
                    sel = act.get("selector")
                    if kind == "click":
                        await page.click(sel, timeout=5000)
                    elif kind == "fill":
                        await page.fill(sel, act.get("value", ""), timeout=5000)
                    elif kind == "goto":
                        await page.goto(act["url"], wait_until="domcontentloaded", timeout=15000)
                    elif kind == "wait":
                        await page.wait_for_timeout(int(act.get("ms", 500)))
                    else:
                        step["ok"] = False
                        step["error"] = "unknown action kind: %s" % kind
                    await page.wait_for_timeout(300)
                except Exception as exc:
                    step["ok"] = False
                    step["error"] = str(exc)
                out["steps"].append(step)

            out["title"] = await page.title()
            out["url"] = page.url

            # Aria tree is the DEFAULT signal: precise selectors/roles, and it
            # works on image-blind routes. (Not a token saving — an 8k tree is
            # ~2k tokens vs ~1.2k for the screenshot.)
            #
            # API NOTE: `page.accessibility` DOES NOT EXIST in playwright 1.61
            # (verified: hasattr(Page, "accessibility") is False). Use
            # `page.aria_snapshot()`, which returns a STR (not a dict — do not
            # json.dumps it). mode="ai" emits the compact agent-oriented format.
            try:
                out["aria"] = (await page.aria_snapshot(mode="ai"))[:20000]
            except Exception as exc:
                out["aria"] = "aria snapshot failed: %s" % exc

            body_text = await page.evaluate(
                "() => (document.body && document.body.innerText || '').trim()"
            )
            out["possibly_blank"] = len(body_text) < 20

            if want_screenshot:
                # JPEG q72, viewport-only, DPR 1 -> ~60-120KB. The marketing
                # validator uses DPR 2 (4x pixels); QA does not need that.
                png = await page.screenshot(full_page=False, type="jpeg", quality=72)
                out["screenshot_b64"] = base64.b64encode(png).decode("ascii")
        finally:
            await browser.close()
    return out


async def main():
    url = sys.argv[1]
    actions = json.loads(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] else []
    want_screenshot = len(sys.argv) > 3 and sys.argv[3] == "1"
    # argv[4]: "1" when ANY target is external -> install the navigation guard.
    # Own-preview-only runs skip it so the hot path stays fast.
    guard_external = len(sys.argv) > 4 and sys.argv[4] == "1"
    try:
        result = await inspect(url, actions, want_screenshot, guard_external)
    except Exception as exc:
        result = {"error": str(exc)}
    print(json.dumps(result))


asyncio.run(main())
